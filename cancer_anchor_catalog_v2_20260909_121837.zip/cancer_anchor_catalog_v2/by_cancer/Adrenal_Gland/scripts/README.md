# 脚本说明

`extract_lineage_subset.R` 从已经完成的全癌种候选菜单和知识卡片中重建当前癌种子集。它不重跑 180G 原始数据，也不执行下游依赖显著性检验。

```bash
Rscript extract_lineage_subset.R <选择结果目录> <知识卡片目录> <新输出目录>
```
