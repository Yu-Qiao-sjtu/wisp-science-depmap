#!/usr/bin/env Rscript
suppressPackageStartupMessages(library(data.table))
args <- commandArgs(TRUE)
if (length(args) != 3L) {
  stop("Usage: extract_lineage_subset.R <selection_result_dir> <knowledge_cards_dir> <output_dir>")
}
lineage_name <- "Cervix"
selection_dir <- normalizePath(args[[1]], mustWork = TRUE)
cards_dir <- normalizePath(args[[2]], mustWork = TRUE)
out <- args[[3]]
dir.create(file.path(out, "data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out, "results"), recursive = TRUE, showWarnings = FALSE)

subset_file <- function(source, target, functional_only = FALSE) {
  x <- fread(source)
  x <- x[lineage == lineage_name]
  if (functional_only) x <- x[matrix %chin% c("Damaging", "Hotspot")]
  fwrite(x, target)
  invisible(nrow(x))
}

subset_file(file.path(selection_dir, "gene_by_lineage_mutation_menu.csv"), file.path(out, "data", "gene_by_lineage_mutation_menu.csv"))
subset_file(file.path(selection_dir, "candidate_anchor_genes_by_lineage.csv"), file.path(out, "data", "candidate_anchor_genes_standard.csv"))
subset_file(file.path(cards_dir, "anchor_gene_cards_all.csv"), file.path(out, "data", "anchor_gene_cards_standard.csv"))
subset_file(file.path(cards_dir, "anchor_gene_cards_all.csv"), file.path(out, "results", "functional_candidates.csv"), TRUE)
subset_file(file.path(selection_dir, "selectable_anchor_genes_by_lineage.csv"), file.path(out, "results", "selectable_anchor_genes_strict.csv"))
subset_file(file.path(cards_dir, "anchor_gene_cards_strict.csv"), file.path(out, "results", "strict_functional_candidates.csv"))
subset_file(file.path(cards_dir, "anchor_gene_cards_priority.csv"), file.path(out, "results", "priority_role_matched_candidates.csv"))
subset_file(file.path(selection_dir, "sensitivity_excluding_common_essential.csv"), file.path(out, "results", "sensitivity_excluding_common_essential.csv"))
cat("Completed lineage subset:", lineage_name, "
")
