# 肺（Lung）突变锚点模块

- 数据版本：DepMap Public 26Q1
- 可分析细胞系：126
- 标准功能候选：634
- 严格功能候选：19
- 角色匹配优先候选：7

## 如何理解

标准门槛为 Mut≥3、WT≥5；严格门槛为 Mut≥10、WT≥5。Damaging 表示 LikelyLoF 预测性功能损伤，Hotspot 表示发布矩阵定义的热点事件。AnySelected 只用于突变景观浏览。候选仅表示样本量允许分析，不表示依赖关系显著或构成合成致死。

## 文件

- `data/gene_by_lineage_mutation_menu.csv`：当前癌种的完整基因×事件计数。
- `data/candidate_anchor_genes_standard.csv`：达到标准门槛的全部事件。
- `data/anchor_gene_cards_standard.csv`：带基因角色和解释的标准候选卡片。
- `results/functional_candidates.csv`：Damaging 与 Hotspot 标准候选。
- `results/selectable_anchor_genes_strict.csv`：达到严格门槛的全部事件。
- `results/strict_functional_candidates.csv`：严格 Damaging/Hotspot 候选。
- `results/priority_role_matched_candidates.csv`：角色与事件匹配的优先候选。
- `results/sensitivity_excluding_common_essential.csv`：排除共同必需基因后的敏感性结果。
- `scripts/extract_lineage_subset.R`：单独重建当前癌种子集。

## 优先查看

| 基因 | 事件 | 等级 | Mut | WT | 突变率 | 角色匹配 |
|---|---|---|---:|---:|---:|---|
| TP53 | Damaging | A_role_matched_strict | 107 | 19 | 84.9% | 是 |
| KRAS | Hotspot | A_role_matched_strict | 38 | 88 | 30.2% | 是 |
| SMARCA4 | Damaging | A_role_matched_strict | 25 | 101 | 19.8% | 是 |
| RB1 | Damaging | A_role_matched_strict | 22 | 104 | 17.5% | 是 |
| CDKN2A | Damaging | A_role_matched_strict | 20 | 106 | 15.9% | 是 |
| KMT2D | Damaging | A_role_matched_strict | 10 | 116 | 7.9% | 是 |
| NF1 | Damaging | A_role_matched_strict | 10 | 116 | 7.9% | 是 |
| TP53 | Hotspot | B_strict_unclassified | 87 | 39 | 69.0% | 否/未分类 |
| TTN | Damaging | B_strict_unclassified | 31 | 95 | 24.6% | 否/未分类 |
| STK11 | Damaging | B_strict_unclassified | 24 | 102 | 19.0% | 否/未分类 |
| MUC16 | Damaging | B_strict_unclassified | 17 | 109 | 13.5% | 否/未分类 |
| RYR2 | Damaging | B_strict_unclassified | 15 | 111 | 11.9% | 否/未分类 |
| CSMD3 | Damaging | B_strict_unclassified | 14 | 112 | 11.1% | 否/未分类 |
| LINC02900 | Damaging | B_strict_unclassified | 14 | 112 | 11.1% | 否/未分类 |
| MUC19 | Damaging | B_strict_unclassified | 12 | 114 | 9.5% | 否/未分类 |
| KEAP1 | Damaging | B_strict_unclassified | 11 | 115 | 8.7% | 否/未分类 |
| CDKN2A | Hotspot | B_strict_unclassified | 10 | 116 | 7.9% | 否/未分类 |
| DNAH9 | Damaging | B_strict_unclassified | 10 | 116 | 7.9% | 否/未分类 |
| PCLO | Damaging | B_strict_unclassified | 10 | 116 | 7.9% | 否/未分类 |
| BCORL1 | Damaging | C_exploratory | 9 | 117 | 7.1% | 是 |

## 限制

- Damaging 是 LikelyLoF 预测标签，不等于实验确认的完整功能丧失。
- Hotspot 与 Damaging 可以重叠，不能当作互斥类别。
- Common Essential 在突变锚点侧保留标记；在依赖靶点侧再做降权或敏感性分析。
- 正式下游分析必须逐个突变—靶点对重新计算有效 Mut/WT，并进行效应量、置信区间和多重检验校正。
