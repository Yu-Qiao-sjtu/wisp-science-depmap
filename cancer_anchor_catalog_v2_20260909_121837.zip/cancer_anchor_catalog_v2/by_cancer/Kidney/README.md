# 肾（Kidney）突变锚点模块

- 数据版本：DepMap Public 26Q1
- 可分析细胞系：35
- 标准功能候选：22
- 严格功能候选：1
- 角色匹配优先候选：0

## 如何理解

标准门槛为 Mut≥3、WT≥5；严格门槛为 Mut≥10、WT≥5。Damaging 表示 LikelyLoF 预测性功能损伤，Hotspot 表示发布矩阵定义的热点事件。AnySelected 只用于突变景观浏览。候选仅表示样本量允许分析，不表示依赖关系显著或构成合成致死。

## 文件

- `data/gene_by_lineage_mutation_menu.csv`：当前癌种的完整基因×事件计数。
- `data/candidate_anchor_genes_standard.csv`：达到标准门槛的全部事件。
- `data/anchor_gene_cards_standard.csv`：带基因角色和解释的标准候选卡片。
- `results/functional_candidates.csv`：Damaging 与 Hotspot 标准候选。
- `results/selectable_anchor_genes_strict.csv`：达到严格门槛的全部事件。
- `results/strict_functional_candidates.csv`：严格 Damaging/Hotspot 候选。
- `results/priority_role_matched_candidates.csv`：角色与事件匹配的优先候选。
- `results/sensitivity_excluding_common_essential.csv`：排除共同必需基因后的敏感性结果。
- `scripts/extract_lineage_subset.R`：单独重建当前癌种子集。

## 优先查看

| 基因 | 事件 | 等级 | Mut | WT | 突变率 | 角色匹配 |
|---|---|---|---:|---:|---:|---|
| VHL | Damaging | B_strict_unclassified | 21 | 14 | 60.0% | 否/未分类 |
| PBRM1 | Damaging | C_exploratory | 9 | 26 | 25.7% | 否/未分类 |
| TP53 | Damaging | C_exploratory | 9 | 26 | 25.7% | 是 |
| VHL | Hotspot | C_exploratory | 8 | 27 | 22.9% | 否/未分类 |
| TP53 | Hotspot | C_exploratory | 7 | 28 | 20.0% | 否/未分类 |
| SETD2 | Damaging | C_exploratory | 6 | 29 | 17.1% | 是 |
| MUC16 | Damaging | C_exploratory | 5 | 30 | 14.3% | 否/未分类 |
| TERT | Hotspot | C_exploratory | 5 | 30 | 14.3% | 否/未分类 |
| CCDST | Damaging | C_exploratory | 4 | 31 | 11.4% | 否/未分类 |
| DNAH14 | Damaging | C_exploratory | 4 | 31 | 11.4% | 否/未分类 |
| LINC02900 | Damaging | C_exploratory | 4 | 31 | 11.4% | 否/未分类 |
| PTEN | Damaging | C_exploratory | 4 | 31 | 11.4% | 是 |
| SLK | Damaging | C_exploratory | 4 | 31 | 11.4% | 否/未分类 |
| AKAP9 | Damaging | C_exploratory | 3 | 32 | 8.6% | 否/未分类 |
| BAP1 | Damaging | C_exploratory | 3 | 32 | 8.6% | 否/未分类 |
| H3-4 | Damaging | C_exploratory | 3 | 32 | 8.6% | 否/未分类 |
| HIF1A | Damaging | C_exploratory | 3 | 32 | 8.6% | 否/未分类 |
| KDM5C | Damaging | C_exploratory | 3 | 32 | 8.6% | 否/未分类 |
| KMT2C | Damaging | C_exploratory | 3 | 32 | 8.6% | 是 |
| LRRK2 | Damaging | C_exploratory | 3 | 32 | 8.6% | 否/未分类 |

## 限制

- Damaging 是 LikelyLoF 预测标签，不等于实验确认的完整功能丧失。
- Hotspot 与 Damaging 可以重叠，不能当作互斥类别。
- Common Essential 在突变锚点侧保留标记；在依赖靶点侧再做降权或敏感性分析。
- 正式下游分析必须逐个突变—靶点对重新计算有效 Mut/WT，并进行效应量、置信区间和多重检验校正。
