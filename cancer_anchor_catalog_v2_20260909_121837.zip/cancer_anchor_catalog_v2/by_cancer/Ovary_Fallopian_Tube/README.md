# 卵巢/输卵管（Ovary/Fallopian Tube）突变锚点模块

- 数据版本：DepMap Public 26Q1
- 可分析细胞系：59
- 标准功能候选：263
- 严格功能候选：4
- 角色匹配优先候选：3

## 如何理解

标准门槛为 Mut≥3、WT≥5；严格门槛为 Mut≥10、WT≥5。Damaging 表示 LikelyLoF 预测性功能损伤，Hotspot 表示发布矩阵定义的热点事件。AnySelected 只用于突变景观浏览。候选仅表示样本量允许分析，不表示依赖关系显著或构成合成致死。

## 文件

- `data/gene_by_lineage_mutation_menu.csv`：当前癌种的完整基因×事件计数。
- `data/candidate_anchor_genes_standard.csv`：达到标准门槛的全部事件。
- `data/anchor_gene_cards_standard.csv`：带基因角色和解释的标准候选卡片。
- `results/functional_candidates.csv`：Damaging 与 Hotspot 标准候选。
- `results/selectable_anchor_genes_strict.csv`：达到严格门槛的全部事件。
- `results/strict_functional_candidates.csv`：严格 Damaging/Hotspot 候选。
- `results/priority_role_matched_candidates.csv`：角色与事件匹配的优先候选。
- `results/sensitivity_excluding_common_essential.csv`：排除共同必需基因后的敏感性结果。
- `scripts/extract_lineage_subset.R`：单独重建当前癌种子集。

## 优先查看

| 基因 | 事件 | 等级 | Mut | WT | 突变率 | 角色匹配 |
|---|---|---|---:|---:|---:|---|
| TP53 | Damaging | A_role_matched_strict | 41 | 18 | 69.5% | 是 |
| ARID1A | Damaging | A_role_matched_strict | 15 | 44 | 25.4% | 是 |
| PIK3CA | Hotspot | A_role_matched_strict | 13 | 46 | 22.0% | 是 |
| TP53 | Hotspot | B_strict_unclassified | 26 | 33 | 44.1% | 否/未分类 |
| KRAS | Hotspot | C_exploratory | 9 | 50 | 15.3% | 是 |
| KMT2B | Damaging | C_exploratory | 8 | 51 | 13.6% | 是 |
| SMARCA4 | Damaging | C_exploratory | 8 | 51 | 13.6% | 是 |
| TERT | Hotspot | C_exploratory | 7 | 52 | 11.9% | 否/未分类 |
| ACVR2A | Damaging | C_exploratory | 6 | 53 | 10.2% | 是 |
| BRCA1 | Damaging | C_exploratory | 6 | 53 | 10.2% | 否/未分类 |
| EP300 | Damaging | C_exploratory | 6 | 53 | 10.2% | 是 |
| FSIP2 | Damaging | C_exploratory | 6 | 53 | 10.2% | 否/未分类 |
| JAKMIP3 | Damaging | C_exploratory | 6 | 53 | 10.2% | 否/未分类 |
| NEB | Damaging | C_exploratory | 6 | 53 | 10.2% | 否/未分类 |
| PTEN | Damaging | C_exploratory | 6 | 53 | 10.2% | 是 |
| TTN | Damaging | C_exploratory | 6 | 53 | 10.2% | 否/未分类 |
| ARHGAP35 | Damaging | C_exploratory | 5 | 54 | 8.5% | 是 |
| BRCA2 | Damaging | C_exploratory | 5 | 54 | 8.5% | 否/未分类 |
| BRD3 | Damaging | C_exploratory | 5 | 54 | 8.5% | 否/未分类 |
| CASP8 | Damaging | C_exploratory | 5 | 54 | 8.5% | 否/未分类 |

## 限制

- Damaging 是 LikelyLoF 预测标签，不等于实验确认的完整功能丧失。
- Hotspot 与 Damaging 可以重叠，不能当作互斥类别。
- Common Essential 在突变锚点侧保留标记；在依赖靶点侧再做降权或敏感性分析。
- 正式下游分析必须逐个突变—靶点对重新计算有效 Mut/WT，并进行效应量、置信区间和多重检验校正。
