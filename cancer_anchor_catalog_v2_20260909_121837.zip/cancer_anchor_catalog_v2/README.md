# 突变锚点：总表与按癌种拆分目录

本目录同时保存两套完全对应的 DepMap Public 26Q1 派生结果：

- `all_cancers/`：30 个癌种/谱系合并后的总数据、总结果、脚本与说明。
- `by_cancer/<癌种>/`：按 OncotreeLineage 拆分，每个癌种独立包含 data、results、scripts、README 和 manifest。
- `lineage_catalog.csv/jsonl`：总表与癌种文件夹之间的映射和候选数量索引。

标准候选门槛为 Mut≥3、WT≥5；严格候选门槛为 Mut≥10、WT≥5。没有达到标准功能候选门槛的癌种仍保留文件夹，用于记录阴性结果。这里整理的是锚点可分析性，不是下游依赖显著性结果。
