# 共享脚本

`build_lineage_catalog.py` 从既有全癌种结果重建全部癌种子目录，不读取原始 180G 数据。
