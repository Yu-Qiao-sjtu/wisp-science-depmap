#!/usr/bin/env python3
import argparse,csv,hashlib,json,os,shutil,uuid
from pathlib import Path

def file_rows(path):
    with path.open(encoding="utf-8-sig",newline="") as f:
        return max(0,sum(1 for _ in f)-1)

def digest(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

p=argparse.ArgumentParser()
p.add_argument("--module-root",required=True)
p.add_argument("--source",default="by_lineage_catalog_v1")
p.add_argument("--target",default="cancer_anchor_catalog_v2")
a=p.parse_args()
root=Path(a.module_root).resolve(); source=root/a.source; target=root/a.target
if not source.is_dir(): raise SystemExit("split source missing")
if target.exists(): raise SystemExit("target already exists")
work=root/f".{a.target}.building-{uuid.uuid4().hex}"
shutil.copytree(source,work)
by=work/"by_cancer"; by.mkdir()
with (work/"lineage_catalog.csv").open(encoding="utf-8-sig",newline="") as f: catalog=list(csv.DictReader(f))
for row in catalog:
    src=work/row["folder"]
    if not src.is_dir(): raise SystemExit("missing lineage folder: "+row["folder"])
    shutil.move(str(src),str(by/row["folder"]))
    row["folder"]="by_cancer/"+row["folder"]
fields=list(catalog[0])
with (work/"lineage_catalog.csv").open("w",encoding="utf-8",newline="") as f:
    w=csv.DictWriter(f,fieldnames=fields,lineterminator="\n"); w.writeheader(); w.writerows(catalog)
with (work/"lineage_catalog.jsonl").open("w",encoding="utf-8") as f:
    for row in catalog: f.write(json.dumps(row,ensure_ascii=False)+"\n")
all_dir=work/"all_cancers"
for sub in ("data","results","scripts","info"): (all_dir/sub).mkdir(parents=True)
selection=root/"results_20260909_v6"; cards=root/"knowledge_cards_v3"
copies={
    selection/"gene_by_lineage_mutation_menu.csv":all_dir/"data/gene_by_lineage_mutation_menu.csv",
    selection/"candidate_anchor_genes_by_lineage.csv":all_dir/"data/candidate_anchor_genes_by_lineage.csv",
    cards/"anchor_gene_cards_all.csv":all_dir/"data/anchor_gene_cards_all.csv",
    selection/"selectable_anchor_genes_by_lineage.csv":all_dir/"results/selectable_anchor_genes_by_lineage.csv",
    cards/"anchor_gene_cards_strict.csv":all_dir/"results/anchor_gene_cards_strict.csv",
    cards/"anchor_gene_cards_priority.csv":all_dir/"results/anchor_gene_cards_priority.csv",
    selection/"sensitivity_excluding_common_essential.csv":all_dir/"results/sensitivity_excluding_common_essential.csv",
    selection/"selectable_gene_counts_by_lineage.csv":all_dir/"results/selectable_gene_counts_by_lineage.csv",
}
for src,dst in copies.items():
    if not src.is_file(): raise SystemExit("missing total source: "+src.name)
    shutil.copy2(src,dst)
for src in sorted((root/"scripts").glob("*")):
    if src.is_file(): shutil.copy2(src,all_dir/"scripts"/src.name)
for src in sorted(root.iterdir()):
    if src.is_file() and src.suffix.lower() in {".md",".json"}: shutil.copy2(src,all_dir/"info"/src.name)
all_manifest={
    "status":"complete","release":"DepMap Public 26Q1","scope":"all 30 OncotreeLineage values",
    "layout_role":"combined total; compare with ../by_cancer/<lineage>/",
    "rows":{str(dst.relative_to(all_dir)):file_rows(dst) for dst in copies.values()},
    "thresholds":{"standard":{"min_mut":3,"min_wt":5},"strict":{"min_mut":10,"min_wt":5}},
    "source_contract":"Copies of completed derived results; raw 180G matrices are not duplicated here.",
    "privacy":"Only relative module locations are documented."
}
(all_dir/"manifest.json").write_text(json.dumps(all_manifest,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
(all_dir/"README.md").write_text("""# 全部癌种突变锚点总表

本目录保存 30 个 OncotreeLineage 合并后的总数据、总结果、正式脚本和模块说明。`../by_cancer/` 保存同一批结果按癌种拆分后的独立文件夹；两者来自相同版本，可以用 `../lineage_catalog.csv` 对照。

## 目录

- `data/gene_by_lineage_mutation_menu.csv`：所有癌种、基因和事件的完整计数。
- `data/candidate_anchor_genes_by_lineage.csv`：所有癌种的标准候选。
- `data/anchor_gene_cards_all.csv`：所有标准候选知识卡片。
- `results/`：严格候选、优先候选、Common Essential 敏感性结果和癌种汇总。
- `scripts/`：06 锚点选择及知识卡片相关正式脚本。
- `info/`：模块说明、突变类型指南、数学审计与 Agent 意图说明。

总表用于跨癌种检索；回答单个癌种问题时优先读取 `../by_cancer/<对应癌种>/`。
""",encoding="utf-8")
root_readme="""# 突变锚点：总表与按癌种拆分目录

本目录同时保存两套完全对应的 DepMap Public 26Q1 派生结果：

- `all_cancers/`：30 个癌种/谱系合并后的总数据、总结果、脚本与说明。
- `by_cancer/<癌种>/`：按 OncotreeLineage 拆分，每个癌种独立包含 data、results、scripts、README 和 manifest。
- `lineage_catalog.csv/jsonl`：总表与癌种文件夹之间的映射和候选数量索引。

标准候选门槛为 Mut≥3、WT≥5；严格候选门槛为 Mut≥10、WT≥5。没有达到标准功能候选门槛的癌种仍保留文件夹，用于记录阴性结果。这里整理的是锚点可分析性，不是下游依赖显著性结果。
"""
(work/"README.md").write_text(root_readme,encoding="utf-8")
with (work/"manifest.json").open(encoding="utf-8") as f: old=json.load(f)
old.update({"status":"complete","layout_version":2,"combined_directory":"all_cancers","split_directory":"by_cancer","lineage_count":len(catalog),"catalog_sha256":digest(work/"lineage_catalog.csv"),"previous_layout_preserved":a.source})
(work/"manifest.json").write_text(json.dumps(old,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
os.replace(work,target)
print(json.dumps({"status":"complete","target":a.target,"lineages":len(catalog),"combined":True,"split":True},ensure_ascii=False))
