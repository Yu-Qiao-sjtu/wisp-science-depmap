#!/usr/bin/env python3
import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import uuid
from collections import Counter, defaultdict
from pathlib import Path


LINEAGE_ZH = {
    "Adrenal Gland": "肾上腺",
    "Ampulla of Vater": "壶腹部",
    "Biliary Tract": "胆道",
    "Bladder/Urinary Tract": "膀胱/泌尿道",
    "Bone": "骨",
    "Bowel": "肠道",
    "Breast": "乳腺",
    "CNS/Brain": "中枢神经系统/脑",
    "Cervix": "宫颈",
    "Esophagus/Stomach": "食管/胃",
    "Eye": "眼",
    "Fibroblast": "成纤维细胞",
    "Head and Neck": "头颈",
    "Kidney": "肾",
    "Liver": "肝",
    "Lung": "肺",
    "Lymphoid": "淋巴系统",
    "Myeloid": "髓系",
    "Other": "其他",
    "Ovary/Fallopian Tube": "卵巢/输卵管",
    "Pancreas": "胰腺",
    "Peripheral Nervous System": "外周神经系统",
    "Pleura": "胸膜",
    "Prostate": "前列腺",
    "Skin": "皮肤",
    "Soft Tissue": "软组织",
    "Testis": "睾丸",
    "Thyroid": "甲状腺",
    "Uterus": "子宫",
    "Vulva/Vagina": "外阴/阴道",
}


def slugify(value):
    return re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_")


def read_header(path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return next(csv.reader(handle))


def partition_csv(source, work, folders, destination, predicate=lambda row: True):
    header = read_header(source)
    handles = {}
    writers = {}
    counts = Counter()
    try:
        for lineage, folder in folders.items():
            target = work / folder / destination
            target.parent.mkdir(parents=True, exist_ok=True)
            handle = target.open("w", encoding="utf-8", newline="")
            handles[lineage] = handle
            writer = csv.DictWriter(handle, fieldnames=header, lineterminator="\n")
            writers[lineage] = writer
            writer.writeheader()
        with source.open("r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                lineage = row.get("lineage")
                if lineage in writers and predicate(row):
                    writers[lineage].writerow(row)
                    counts[lineage] += 1
    finally:
        for handle in handles.values():
            handle.close()
    return counts


def truthy(value):
    return str(value).lower() in {"true", "t", "1"}


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_extractor(lineage):
    quoted = json.dumps(lineage, ensure_ascii=False)
    return f'''#!/usr/bin/env Rscript
suppressPackageStartupMessages(library(data.table))
args <- commandArgs(TRUE)
if (length(args) != 3L) {{
  stop("Usage: extract_lineage_subset.R <selection_result_dir> <knowledge_cards_dir> <output_dir>")
}}
lineage_name <- {quoted}
selection_dir <- normalizePath(args[[1]], mustWork = TRUE)
cards_dir <- normalizePath(args[[2]], mustWork = TRUE)
out <- args[[3]]
dir.create(file.path(out, "data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out, "results"), recursive = TRUE, showWarnings = FALSE)

subset_file <- function(source, target, functional_only = FALSE) {{
  x <- fread(source)
  x <- x[lineage == lineage_name]
  if (functional_only) x <- x[matrix %chin% c("Damaging", "Hotspot")]
  fwrite(x, target)
  invisible(nrow(x))
}}

subset_file(file.path(selection_dir, "gene_by_lineage_mutation_menu.csv"), file.path(out, "data", "gene_by_lineage_mutation_menu.csv"))
subset_file(file.path(selection_dir, "candidate_anchor_genes_by_lineage.csv"), file.path(out, "data", "candidate_anchor_genes_standard.csv"))
subset_file(file.path(cards_dir, "anchor_gene_cards_all.csv"), file.path(out, "data", "anchor_gene_cards_standard.csv"))
subset_file(file.path(cards_dir, "anchor_gene_cards_all.csv"), file.path(out, "results", "functional_candidates.csv"), TRUE)
subset_file(file.path(selection_dir, "selectable_anchor_genes_by_lineage.csv"), file.path(out, "results", "selectable_anchor_genes_strict.csv"))
subset_file(file.path(cards_dir, "anchor_gene_cards_strict.csv"), file.path(out, "results", "strict_functional_candidates.csv"))
subset_file(file.path(cards_dir, "anchor_gene_cards_priority.csv"), file.path(out, "results", "priority_role_matched_candidates.csv"))
subset_file(file.path(selection_dir, "sensitivity_excluding_common_essential.csv"), file.path(out, "results", "sensitivity_excluding_common_essential.csv"))
cat("Completed lineage subset:", lineage_name, "\n")
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--module-root", required=True)
    parser.add_argument("--target-name", default="by_lineage_catalog_v1")
    args = parser.parse_args()

    root = Path(args.module_root).resolve()
    selection = root / "results_20260909_v6"
    cards = root / "knowledge_cards_v3"
    sources = {
        "full_menu": selection / "gene_by_lineage_mutation_menu.csv",
        "standard": selection / "candidate_anchor_genes_by_lineage.csv",
        "strict_all": selection / "selectable_anchor_genes_by_lineage.csv",
        "sensitivity": selection / "sensitivity_excluding_common_essential.csv",
        "cards_all": cards / "anchor_gene_cards_all.csv",
        "cards_strict": cards / "anchor_gene_cards_strict.csv",
        "cards_priority": cards / "anchor_gene_cards_priority.csv",
    }
    missing = [key for key, path in sources.items() if not path.is_file()]
    if missing:
        raise SystemExit("Missing inputs: " + ", ".join(missing))

    target = root / args.target_name
    if target.exists():
        raise SystemExit(f"Target already exists: {args.target_name}")
    work = root / f".{args.target_name}.building-{uuid.uuid4().hex}"
    work.mkdir(parents=True)

    cohort = {}
    with sources["full_menu"].open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            lineage = row["lineage"]
            n = int(float(row["mut_n"])) + int(float(row["wt_n"]))
            cohort[lineage] = max(cohort.get(lineage, 0), n)
    lineages = sorted(cohort)
    folders = {lineage: slugify(lineage) for lineage in lineages}
    if len(set(folders.values())) != len(folders):
        raise SystemExit("Lineage folder collision")

    for folder in folders.values():
        (work / folder / "data").mkdir(parents=True)
        (work / folder / "results").mkdir(parents=True)
        (work / folder / "scripts").mkdir(parents=True)

    counts = defaultdict(dict)
    jobs = [
        ("full_menu", "data/gene_by_lineage_mutation_menu.csv", lambda row: True),
        ("standard", "data/candidate_anchor_genes_standard.csv", lambda row: True),
        ("cards_all", "data/anchor_gene_cards_standard.csv", lambda row: True),
        ("cards_all", "results/functional_candidates.csv", lambda row: row.get("matrix") in {"Damaging", "Hotspot"}),
        ("strict_all", "results/selectable_anchor_genes_strict.csv", lambda row: True),
        ("cards_strict", "results/strict_functional_candidates.csv", lambda row: True),
        ("cards_priority", "results/priority_role_matched_candidates.csv", lambda row: True),
        ("sensitivity", "results/sensitivity_excluding_common_essential.csv", lambda row: True),
    ]
    for source_key, destination, predicate in jobs:
        part_counts = partition_csv(sources[source_key], work, folders, destination, predicate)
        for lineage in lineages:
            counts[lineage][destination] = part_counts.get(lineage, 0)

    matrix_counts = defaultdict(Counter)
    recommendations = defaultdict(list)
    with sources["cards_all"].open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            lineage = row["lineage"]
            matrix_counts[lineage][f"standard_{row['matrix']}"] += 1
            if row["matrix"] in {"Damaging", "Hotspot"}:
                recommendations[lineage].append(row)
    with sources["strict_all"].open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            matrix_counts[row["lineage"]][f"strict_{row['matrix']}"] += 1

    catalog_rows = []
    for lineage in lineages:
        folder = folders[lineage]
        module = work / folder
        ranked = sorted(
            recommendations[lineage],
            key=lambda row: (
                {"A_role_matched_strict": 0, "B_strict_unclassified": 1, "C_exploratory": 2}.get(row.get("selection_tier"), 3),
                -int(float(row.get("mut_n") or 0)),
                row.get("gene", ""),
                row.get("matrix", ""),
            ),
        )
        top = ranked[:20]
        priority_count = counts[lineage]["results/priority_role_matched_candidates.csv"]
        strict_functional_count = counts[lineage]["results/strict_functional_candidates.csv"]
        standard_functional_count = counts[lineage]["results/functional_candidates.csv"]
        manifest = {
            "status": "complete",
            "release": "DepMap Public 26Q1",
            "lineage": lineage,
            "lineage_zh": LINEAGE_ZH.get(lineage, lineage),
            "cohort_n": cohort[lineage],
            "thresholds": {"standard": {"min_mut": 3, "min_wt": 5}, "strict": {"min_mut": 10, "min_wt": 5}},
            "event_definitions": ["AnySelected", "Damaging", "Hotspot"],
            "counts": counts[lineage],
            "matrix_counts": dict(matrix_counts[lineage]),
            "source_contract": "Derived from the completed 26Q1 anchor menu and knowledge cards; no raw mutation or dependency matrix is copied into this folder.",
            "interpretation": "Candidate status means analyzable sample support, not a significant dependency association.",
        }
        (module / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (module / "lineage.txt").write_text(lineage + "\n", encoding="utf-8")
        (module / "scripts" / "extract_lineage_subset.R").write_text(build_extractor(lineage), encoding="utf-8")
        (module / "scripts" / "README.md").write_text(
            "# 脚本说明\n\n"
            "`extract_lineage_subset.R` 从已经完成的全癌种候选菜单和知识卡片中重建当前癌种子集。"
            "它不重跑 180G 原始数据，也不执行下游依赖显著性检验。\n\n"
            "```bash\nRscript extract_lineage_subset.R <选择结果目录> <知识卡片目录> <新输出目录>\n```\n",
            encoding="utf-8",
        )

        lines = [
            f"# {LINEAGE_ZH.get(lineage, lineage)}（{lineage}）突变锚点模块",
            "",
            f"- 数据版本：DepMap Public 26Q1",
            f"- 可分析细胞系：{cohort[lineage]}",
            f"- 标准功能候选：{standard_functional_count}",
            f"- 严格功能候选：{strict_functional_count}",
            f"- 角色匹配优先候选：{priority_count}",
            "",
            "## 如何理解",
            "",
            "标准门槛为 Mut≥3、WT≥5；严格门槛为 Mut≥10、WT≥5。Damaging 表示 LikelyLoF 预测性功能损伤，Hotspot 表示发布矩阵定义的热点事件。AnySelected 只用于突变景观浏览。候选仅表示样本量允许分析，不表示依赖关系显著或构成合成致死。",
            "",
            "## 文件",
            "",
            "- `data/gene_by_lineage_mutation_menu.csv`：当前癌种的完整基因×事件计数。",
            "- `data/candidate_anchor_genes_standard.csv`：达到标准门槛的全部事件。",
            "- `data/anchor_gene_cards_standard.csv`：带基因角色和解释的标准候选卡片。",
            "- `results/functional_candidates.csv`：Damaging 与 Hotspot 标准候选。",
            "- `results/selectable_anchor_genes_strict.csv`：达到严格门槛的全部事件。",
            "- `results/strict_functional_candidates.csv`：严格 Damaging/Hotspot 候选。",
            "- `results/priority_role_matched_candidates.csv`：角色与事件匹配的优先候选。",
            "- `results/sensitivity_excluding_common_essential.csv`：排除共同必需基因后的敏感性结果。",
            "- `scripts/extract_lineage_subset.R`：单独重建当前癌种子集。",
            "",
            "## 优先查看",
            "",
        ]
        if top:
            lines.extend(["| 基因 | 事件 | 等级 | Mut | WT | 突变率 | 角色匹配 |", "|---|---|---|---:|---:|---:|---|"])
            for row in top:
                lines.append(
                    f"| {row['gene']} | {row['matrix']} | {row['selection_tier']} | {row['mut_n']} | {row['wt_n']} | {float(row['mut_rate']):.1%} | {'是' if truthy(row.get('role_match')) else '否/未分类'} |"
                )
        else:
            lines.append("当前癌种没有达到 Mut≥3、WT≥5 的 Damaging 或 Hotspot 功能候选。保留文件夹用于明确记录阴性筛选结果。")
        lines.extend([
            "",
            "## 限制",
            "",
            "- Damaging 是 LikelyLoF 预测标签，不等于实验确认的完整功能丧失。",
            "- Hotspot 与 Damaging 可以重叠，不能当作互斥类别。",
            "- Common Essential 在突变锚点侧保留标记；在依赖靶点侧再做降权或敏感性分析。",
            "- 正式下游分析必须逐个突变—靶点对重新计算有效 Mut/WT，并进行效应量、置信区间和多重检验校正。",
        ])
        (module / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
        (module / "results" / "summary.json").write_text(json.dumps({
            "lineage": lineage,
            "cohort_n": cohort[lineage],
            "standard_functional_count": standard_functional_count,
            "strict_functional_count": strict_functional_count,
            "priority_role_matched_count": priority_count,
            "top_candidates": [{
                "gene": row["gene"], "matrix": row["matrix"], "selection_tier": row["selection_tier"],
                "mut_n": int(float(row["mut_n"])), "wt_n": int(float(row["wt_n"])),
                "mut_rate": float(row["mut_rate"]), "role_match": truthy(row.get("role_match")),
            } for row in top],
        }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        catalog_rows.append({
            "lineage": lineage,
            "lineage_zh": LINEAGE_ZH.get(lineage, lineage),
            "folder": folder,
            "cohort_n": cohort[lineage],
            "standard_functional_count": standard_functional_count,
            "strict_functional_count": strict_functional_count,
            "priority_role_matched_count": priority_count,
            "has_strict_functional_candidate": strict_functional_count > 0,
        })

    catalog_fields = list(catalog_rows[0])
    with (work / "lineage_catalog.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=catalog_fields, lineterminator="\n")
        writer.writeheader(); writer.writerows(catalog_rows)
    with (work / "lineage_catalog.jsonl").open("w", encoding="utf-8") as handle:
        for row in catalog_rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")

    root_readme = [
        "# 按癌种整理的突变锚点目录",
        "",
        "本目录把完成的 DepMap Public 26Q1 突变锚点菜单按 OncotreeLineage 拆分。每个癌种都有独立的数据、结果、重建脚本、README 和 manifest；没有达到标准门槛的癌种也保留文件夹，以记录阴性筛选结果。",
        "",
        "- 癌种/谱系数：30",
        "- 标准门槛：Mut≥3、WT≥5",
        "- 严格门槛：Mut≥10、WT≥5",
        "- `lineage_catalog.csv/jsonl`：全目录索引",
        "- `_shared/build_lineage_catalog.py`：全目录重建脚本",
        "",
        "目录只保存派生的分组计数和知识卡片，不复制原始大矩阵。",
    ]
    (work / "README.md").write_text("\n".join(root_readme) + "\n", encoding="utf-8")
    shared = work / "_shared"
    shared.mkdir()
    source_copy = shared / "build_lineage_catalog.py"
    # The calling process copies this script into _shared after the atomic publish.
    (shared / "README.md").write_text(
        "# 共享脚本\n\n`build_lineage_catalog.py` 从既有全癌种结果重建全部癌种子目录，不读取原始 180G 数据。\n",
        encoding="utf-8",
    )

    files = [p for p in work.rglob("*") if p.is_file()]
    manifest = {
        "status": "complete",
        "release": "DepMap Public 26Q1",
        "lineage_count": len(lineages),
        "folder_count": len(folders),
        "file_count_before_generator_copy": len(files),
        "total_bytes_before_generator_copy": sum(p.stat().st_size for p in files),
        "catalog_sha256": sha256(work / "lineage_catalog.csv"),
        "source_files": {key: str(path.relative_to(root)) for key, path in sources.items()},
        "privacy": "Only module-relative source locations are recorded.",
    }
    (work / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(work, target)
    print(json.dumps({"status": "complete", "target_name": args.target_name, "lineage_count": len(lineages), "folders": len(folders)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

