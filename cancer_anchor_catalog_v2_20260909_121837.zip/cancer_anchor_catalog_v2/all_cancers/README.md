# 全部癌种突变锚点总表

本目录保存 30 个 OncotreeLineage 合并后的总数据、总结果、正式脚本和模块说明。`../by_cancer/` 保存同一批结果按癌种拆分后的独立文件夹；两者来自相同版本，可以用 `../lineage_catalog.csv` 对照。

## 目录

- `data/gene_by_lineage_mutation_menu.csv`：所有癌种、基因和事件的完整计数。
- `data/candidate_anchor_genes_by_lineage.csv`：所有癌种的标准候选。
- `data/anchor_gene_cards_all.csv`：所有标准候选知识卡片。
- `results/`：严格候选、优先候选、Common Essential 敏感性结果和癌种汇总。
- `scripts/`：06 锚点选择及知识卡片相关正式脚本。
- `info/`：模块说明、突变类型指南、数学审计与 Agent 意图说明。

总表用于跨癌种检索；回答单个癌种问题时优先读取 `../by_cancer/<对应癌种>/`。
